#ifndef __SMARTPA_DEGUG_COMMON_H__
#define __SMARTPA_DEGUG_COMMON_H__
#include <linux/i2c.h>

int smartpa_debug_probe(struct i2c_client *client);

#endif
